package com.teguh.moviejetpack

import androidx.recyclerview.widget.RecyclerView
import androidx.test.espresso.Espresso
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.IdlingRegistry
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.rules.ActivityScenarioRule
import com.teguh.moviejetpack.utils.EspressonIdlingResource
import com.teguh.moviejetpack.utils.MyDummyData
import org.junit.*
import org.junit.runners.MethodSorters

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
class HomeActivityTest {

    @get:Rule
    var activityRule = ActivityScenarioRule(HomeActivity::class.java)

    @Before
    fun setup() {
        IdlingRegistry.getInstance().register(EspressonIdlingResource.espressoTestIdlingResource)
    }

    @After
    fun tearDown() {
        IdlingRegistry.getInstance().unregister(EspressonIdlingResource.espressoTestIdlingResource)
    }

    @Test
    fun a_loadMovies() {
        onView(withId(R.id.movie_recyclerview)).check(matches(isDisplayed()))
        onView(withId(R.id.movie_recyclerview)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(4))
    }

    @Test
    fun b_loadDetailMovie() {
        onView(withId(R.id.movie_recyclerview)).perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, click()))
        onView(withId(R.id.title)).check(matches(isDisplayed()))
        onView(withId(R.id.vote_average)).check(matches(isDisplayed()))
        onView(withId(R.id.deskripsi)).check(matches(isDisplayed()))
    }

    @Test
    fun c_loadTvShow() {
        onView(withText("Tv Shows")).perform(click())
        onView(withId(R.id.tvshow_recyclerview)).check(matches(isDisplayed()))
        onView(withId(R.id.tvshow_recyclerview)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(4))
    }

    @Test
    fun d_loadDetailTvShow() {
        onView(withText("Tv Shows")).perform(click())
        onView(withId(R.id.tvshow_recyclerview)).perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, click()))
        onView(withId(R.id.title)).check(matches(isDisplayed()))
        onView(withId(R.id.vote_average)).check(matches(isDisplayed()))
        onView(withId(R.id.deskripsi)).check(matches(isDisplayed()))
    }

}
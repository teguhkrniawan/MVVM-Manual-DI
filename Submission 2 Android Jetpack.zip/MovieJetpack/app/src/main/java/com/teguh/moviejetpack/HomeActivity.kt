package com.teguh.moviejetpack

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.teguh.moviejetpack.databinding.ActivityHomeBinding

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val viewPagerAdapter = HomeAdapter(this, supportFragmentManager)
        binding.homeViewPager.adapter = viewPagerAdapter
        binding.homeTabLayout.setupWithViewPager(binding.homeViewPager)

        supportActionBar?.elevation = 0f
    }
}
package com.teguh.moviejetpack

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.teguh.moviejetpack.ui.movies.MoviesFragment
import com.teguh.moviejetpack.ui.tvshow.TvShowFragment

class HomeAdapter(private val mContext: Context, private val fragmentManager: FragmentManager) :
    FragmentPagerAdapter(fragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT)
{
    companion object {
        private val TAB_TITLES = intArrayOf(R.string.movies, R.string.tv_show)
    }

    override fun getItem(position: Int): Fragment {

        var myFragment = Fragment()

        when (position) {
            0 -> myFragment = MoviesFragment()
            1 -> myFragment = TvShowFragment()
            else -> myFragment = Fragment()
        }

        return myFragment
    }

    override fun getCount(): Int {
        return 2
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return mContext.resources.getString(TAB_TITLES[position])
    }
}
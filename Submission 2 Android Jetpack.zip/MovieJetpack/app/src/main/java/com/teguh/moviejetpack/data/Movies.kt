package com.teguh.moviejetpack.data

data class Movies(
    val idMovie: String? = null,
    val originalTitle: String? = null,
    val overview: String? = null,
    val voteAverage: String? = null,
    val posterPath: String? = null
)
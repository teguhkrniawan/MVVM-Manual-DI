package com.teguh.moviejetpack.data

data class TvShow(
    val idTvshow: String? = null,
    val originalName: String? = null,
    val overview: String? = null,
    val averageVote: String? = null,
    val posterPath: String? = null
)
package com.teguh.moviejetpack.data.repo

import androidx.lifecycle.LiveData
import com.teguh.moviejetpack.data.Movies
import com.teguh.moviejetpack.data.TvShow
import com.teguh.moviejetpack.data.source.remote.response.MovieResponse

interface AppRepoCallback {
    fun getNowPlayingMovies(): LiveData<List<Movies>>
    fun getPopularTvShow(): LiveData<List<TvShow>>
    fun getDetailMovie(idMovies: Int): LiveData<Movies>
    fun getDetailTvShow(idTvShow: Int): LiveData<TvShow>
}
package com.teguh.moviejetpack.data.source.remote

import com.teguh.moviejetpack.data.source.remote.response.MovieResponse

interface RemoteDataCallback {
    fun onMovieReceived(movieResponse: List<MovieResponse>) {}
    fun onTvShowReceived(tvShowResponse: List<MovieResponse>) {}
    fun onDetailMovieReceiverd(movies: MovieResponse) {}
    fun onDetailTvShowReceived(tvshow: MovieResponse) {}
    fun onFailedResponse(message: String)
}
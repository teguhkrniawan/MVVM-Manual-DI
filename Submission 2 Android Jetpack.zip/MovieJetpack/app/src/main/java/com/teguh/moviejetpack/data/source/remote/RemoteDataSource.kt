package com.teguh.moviejetpack.data.source.remote

import android.util.Log
import com.teguh.moviejetpack.data.source.remote.response.GeneralResponse
import com.teguh.moviejetpack.data.source.remote.response.MovieResponse
import com.teguh.moviejetpack.network.ApiClient
import com.teguh.moviejetpack.utils.EspressonIdlingResource
import okhttp3.ResponseBody
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Converter
import retrofit2.Response


class RemoteDataSource {

    companion object {

        val TAG: String = RemoteDataSource::class.java.simpleName

        @Volatile
        private var instance: RemoteDataSource? = null

        fun getInstance() : RemoteDataSource =
            instance ?: synchronized(this) {
                instance ?: RemoteDataSource()
            }
    }

    suspend fun loadNowPlayingMovies(listener: RemoteDataCallback) {

       EspressonIdlingResource.increment()

       ApiClient.getInstance.getMoviesNowPlaying()
           .enqueue(object : Callback<GeneralResponse> {
               override fun onFailure(call: Call<GeneralResponse>, t: Throwable) {
                   Log.d(TAG, "onFailure: ${t.localizedMessage}")
                   t.localizedMessage?.let { listener.onFailedResponse(it) }
                   EspressonIdlingResource.decrement()
               }

               override fun onResponse(
                   call: Call<GeneralResponse>,
                   response: Response<GeneralResponse>
               ) {
                   if (response.code() == 401) {
                       if (!response.isSuccessful) {
                           try {
                               val jsonObject = JSONObject(response.errorBody()?.string())
                               val statusCode = jsonObject.getString("status_code")
                               val message = jsonObject.getString("status_message")

                               Log.d(TAG, "onResponse: $statusCode dan $message")
                               listener.onFailedResponse(message)
                               EspressonIdlingResource.decrement()
                           } catch (e: Exception) {
                               e.printStackTrace()
                               EspressonIdlingResource.decrement()
                           }
                       }
                   }

                   if (response.code() == 200) {
                       if (response.isSuccessful) {
                          response.body()?.result?.let {
                              listener.onMovieReceived(it)
                              EspressonIdlingResource.decrement()
                          }
                       }
                   }
               }

           })
    }

    suspend fun loadPopularTvShow(listener: RemoteDataCallback) {

        EspressonIdlingResource.increment()

        ApiClient.getInstance.getTvShowPopular()
            .enqueue(object : Callback<GeneralResponse> {
                override fun onFailure(call: Call<GeneralResponse>, t: Throwable) {
                    Log.d(TAG, "onFailure: ${t.localizedMessage}")
                    t.localizedMessage?.let { listener.onFailedResponse(it) }
                    EspressonIdlingResource.decrement()
                }

                override fun onResponse(
                    call: Call<GeneralResponse>,
                    response: Response<GeneralResponse>
                ) {
                    if (response.code() == 401) {
                        if (!response.isSuccessful) {
                            try {
                                val jsonObject = JSONObject(response.errorBody()?.string())
                                val statusCode = jsonObject.getString("status_code")
                                val message = jsonObject.getString("status_message")

                                Log.d(TAG, "onResponse: $statusCode dan $message")
                                listener.onFailedResponse(message)
                                EspressonIdlingResource.decrement()
                            } catch (e: Exception) {
                                e.printStackTrace()
                                EspressonIdlingResource.decrement()
                            }
                        }
                    }

                    if (response.code() == 200) {
                        if (response.isSuccessful) {
                            response.body()?.result?.let {
                                listener.onTvShowReceived(it)
                                EspressonIdlingResource.decrement()
                            }
                        }
                    }
                }

            })
    }

    suspend fun loadDetailMovies(idMovie: Int, listener: RemoteDataCallback) {

        EspressonIdlingResource.increment()

        ApiClient.getInstance.getDetailMovie(idMovie)
            .enqueue(object : Callback<MovieResponse> {
                override fun onFailure(call: Call<MovieResponse>, t: Throwable) {
                    Log.d(TAG, "onFailure: ${t.localizedMessage}")
                    t.localizedMessage?.let { listener.onFailedResponse(it) }
                    EspressonIdlingResource.decrement()
                }

                override fun onResponse(
                    call: Call<MovieResponse>,
                    response: Response<MovieResponse>
                ) {
                    if (response.code() == 200) {
                        if (response.isSuccessful) {
                            response.body()?.let {
                                listener.onDetailMovieReceiverd(it)
                                EspressonIdlingResource.decrement()
                            }
                        }
                    }
                }
            })
    }

    suspend fun loadDetailTvShow(idTvShow: Int, listener: RemoteDataCallback) {

        EspressonIdlingResource.increment()

        ApiClient.getInstance.getDetailTvShow(idTvShow)
            .enqueue(object : Callback<MovieResponse> {
                override fun onFailure(call: Call<MovieResponse>, t: Throwable) {
                    Log.d(TAG, "onFailure: ${t.localizedMessage}")
                    t.localizedMessage?.let { listener.onFailedResponse(it) }
                    EspressonIdlingResource.decrement()
                }

                override fun onResponse(
                    call: Call<MovieResponse>,
                    response: Response<MovieResponse>
                ) {
                    if (response.code() == 200) {
                        if (response.isSuccessful) {
                            response.body()?.let {
                                listener.onDetailTvShowReceived(it)
                                EspressonIdlingResource.decrement()
                            }
                        }
                    }
                }

            })
    }

}
package com.teguh.moviejetpack.data.source.remote.response

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class GeneralResponse(

	@field:SerializedName("results")
	val result: List<MovieResponse>? = null

) : Parcelable

package com.teguh.moviejetpack.di

import com.teguh.moviejetpack.data.repo.AppRepository
import com.teguh.moviejetpack.data.source.remote.RemoteDataSource

object Injection {
    fun provideMovieRepository(): AppRepository {
        val remoteDataSource = RemoteDataSource.getInstance()
        return AppRepository.getInstance(remoteDataSource)
    }
}
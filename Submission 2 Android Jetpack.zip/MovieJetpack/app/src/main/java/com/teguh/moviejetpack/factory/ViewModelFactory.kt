package com.teguh.moviejetpack.factory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.teguh.moviejetpack.data.repo.AppRepository
import com.teguh.moviejetpack.di.Injection
import com.teguh.moviejetpack.ui.detail.DetailViewModel
import com.teguh.moviejetpack.ui.movies.MovieViewModel
import com.teguh.moviejetpack.ui.tvshow.TvShowViewModel

class ViewModelFactory private constructor(private val appRepository: AppRepository)
    : ViewModelProvider.NewInstanceFactory()
{

    companion object {
        @Volatile
        private var instance: ViewModelFactory? = null

        fun getInstance(): ViewModelFactory =
            instance ?: synchronized(this) {
                instance ?: ViewModelFactory(Injection.provideMovieRepository())
            }
    }

    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(MovieViewModel::class.java) -> { MovieViewModel(appRepository) as T }
            modelClass.isAssignableFrom(TvShowViewModel::class.java) -> { TvShowViewModel(appRepository) as T }
            modelClass.isAssignableFrom(DetailViewModel::class.java) -> { DetailViewModel(appRepository) as T }
            else -> throw Throwable("Uknown viewmodel class:" + modelClass.name)
        }
    }

}
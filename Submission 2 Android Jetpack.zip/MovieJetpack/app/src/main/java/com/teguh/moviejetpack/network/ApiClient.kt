package com.teguh.moviejetpack.network

import com.teguh.moviejetpack.BuildConfig
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ApiClient {

    private const val BASE_URL: String = "https://api.themoviedb.org/3/"
    const val MY_API_TMDB: String = "f5a66c3dc572fbc10086db3cebcf8e5c"
    const val IMG_PATH_URL: String = "https://image.tmdb.org/t/p/w600_and_h900_bestv2"

    private val loggingInterceptor = HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)
    private val client = OkHttpClient.Builder().apply {
        addInterceptor(loggingInterceptor)
    }.build()

    private val retrofit: Retrofit.Builder by lazy {
        Retrofit.Builder().apply {
            baseUrl(BASE_URL)
            client(client)
            addConverterFactory(GsonConverterFactory.create())
        }
    }

    val getInstance: ApiService by lazy {
        retrofit.build().create(ApiService::class.java)
    }

}
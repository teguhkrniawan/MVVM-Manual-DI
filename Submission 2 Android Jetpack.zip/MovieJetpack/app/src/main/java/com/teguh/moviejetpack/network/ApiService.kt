package com.teguh.moviejetpack.network

import com.teguh.moviejetpack.data.source.remote.response.GeneralResponse
import com.teguh.moviejetpack.data.source.remote.response.MovieResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    // for load movies now playing
    @GET("movie/now_playing")
    fun getMoviesNowPlaying(
        @Query("api_key") apiKey: String = ApiClient.MY_API_TMDB
    ): Call<GeneralResponse>

    // for load tv shows now playing
    @GET("tv/popular")
    fun getTvShowPopular(
        @Query("api_key") apiKey: String = ApiClient.MY_API_TMDB
    ): Call<GeneralResponse>

    // for load detail movie
    @GET("movie/{movie_id}")
    fun getDetailMovie(
        @Path("movie_id") movieId: Int,
        @Query("api_key") apiKey: String = ApiClient.MY_API_TMDB
    ): Call<MovieResponse>

    // for load detail tv show
    @GET("tv/{tv_id}")
    fun getDetailTvShow(
        @Path("tv_id") tvShowId: Int,
        @Query("api_key") apiKey: String = ApiClient.MY_API_TMDB
    ): Call<MovieResponse>

}
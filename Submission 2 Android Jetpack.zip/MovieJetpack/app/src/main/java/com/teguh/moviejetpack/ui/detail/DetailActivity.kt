package com.teguh.moviejetpack.ui.detail

import android.os.Bundle
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.teguh.moviejetpack.R
import com.teguh.moviejetpack.databinding.ActivityDetailBinding
import com.teguh.moviejetpack.databinding.ContentDetailBinding
import com.teguh.moviejetpack.factory.ViewModelFactory
import com.teguh.moviejetpack.network.ApiClient

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private lateinit var content: ContentDetailBinding

    companion object {
        const val EXTRA_CATEGORIES = "extra_categories"
        const val EXTRA_ID = "extra_id"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        content = binding.contentDetail
        setContentView(binding.root)

        // setup toolbar
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setTitle(R.string.detail_movies)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val factory = ViewModelFactory.getInstance()
        val viewmodel = ViewModelProvider(this, factory)[DetailViewModel::class.java]

        val extras = intent.extras
        if (extras != null) {
            val categories = extras.getString(EXTRA_CATEGORIES)
            val id = extras.getString(EXTRA_ID)
            if (categories != null && id != null) {
                when (categories) {
                    "movies" -> {
                        viewmodel.setIdMovie(id)
                        viewmodel.getmovieDetail().observe(this, Observer {movies ->
                            Glide.with(this)
                                .load(ApiClient.IMG_PATH_URL + movies.posterPath)
                                .apply(RequestOptions.placeholderOf(R.drawable.ic_loading))
                                .error(R.drawable.ic_error)
                                .into(content.posterPath)
                            content.title.text = movies.originalTitle
                            content.voteAverage.text = resources.getString(R.string.rate, movies.voteAverage)
                            content.deskripsi.text = movies.overview
                        })
                    }

                    "tvshow" -> {
                        viewmodel.setIdTvShow(id)
                        viewmodel.getTvShowDetail().observe(this, Observer { movies ->
                            Glide.with(this)
                                .load(ApiClient.IMG_PATH_URL + movies.posterPath)
                                .apply(RequestOptions.placeholderOf(R.drawable.ic_loading))
                                .error(R.drawable.ic_error)
                                .into(content.posterPath)
                            content.title.text = movies.originalName
                            content.voteAverage.text = resources.getString(R.string.rate, movies.averageVote)
                            content.deskripsi.text = movies.overview
                        })
                    }
                }
            }
        }

    }
}
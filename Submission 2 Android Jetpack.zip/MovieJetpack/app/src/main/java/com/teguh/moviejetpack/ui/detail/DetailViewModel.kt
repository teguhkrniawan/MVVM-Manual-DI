package com.teguh.moviejetpack.ui.detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.teguh.moviejetpack.data.Movies
import com.teguh.moviejetpack.data.TvShow
import com.teguh.moviejetpack.data.repo.AppRepository
import com.teguh.moviejetpack.utils.MyDummyData

class DetailViewModel(private val appRepository: AppRepository): ViewModel() {

    private lateinit var idMovies: String
    private lateinit var idTvShow: String

    fun setIdMovie(id: String){
        this.idMovies = id
    }

    fun setIdTvShow(id: String){
        this.idTvShow = id
    }

    fun getmovieDetail(): LiveData<Movies>{
        return appRepository.getDetailMovie(idMovies.toInt())
    }

    fun getTvShowDetail(): LiveData<TvShow> {
        return appRepository.getDetailTvShow(idTvShow.toInt())
    }

}
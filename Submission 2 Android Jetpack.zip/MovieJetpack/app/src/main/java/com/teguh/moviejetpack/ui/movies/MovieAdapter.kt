package com.teguh.moviejetpack.ui.movies

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.teguh.moviejetpack.R
import com.teguh.moviejetpack.data.Movies
import com.teguh.moviejetpack.databinding.ListItemsMoviesBinding
import com.teguh.moviejetpack.network.ApiClient
import com.teguh.moviejetpack.ui.detail.DetailActivity

class MovieAdapter : RecyclerView.Adapter<MovieAdapter.MyViewHolder>() {

    private val listMovies = ArrayList<Movies>()

    inner class MyViewHolder(private val movieItemBinding: ListItemsMoviesBinding): RecyclerView.ViewHolder(movieItemBinding.root) {
        fun bind(movie: Movies) {
            with(movieItemBinding) {
                movieItemBinding.itemsMovieTitle.text = movie.originalTitle
                movieItemBinding.itemsMovieVote.text = itemView.resources.getString(R.string.rate, movie.voteAverage)
                Glide.with(itemView.context)
                    .load(ApiClient.IMG_PATH_URL + movie.posterPath)
                    .apply(RequestOptions.placeholderOf(R.drawable.ic_loading))
                    .error(R.drawable.ic_error)
                    .into(this.itemsMoviePoster)
                itemView.setOnClickListener {
                    val intent = Intent(itemView.context, DetailActivity::class.java)
                    intent.putExtra(DetailActivity.EXTRA_CATEGORIES, "movies")
                    intent.putExtra(DetailActivity.EXTRA_ID, movie.idMovie)
                    itemView.context.startActivity(intent)
                }
            }
        }
    }

    fun setListMovies(list: List<Movies>?) {
        if (list == null)
            return
        listMovies.clear()
        listMovies.addAll(list)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ListItemsMoviesBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun getItemCount(): Int {
       return listMovies.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val movie = listMovies[position]
        holder.bind(movie)
    }

}

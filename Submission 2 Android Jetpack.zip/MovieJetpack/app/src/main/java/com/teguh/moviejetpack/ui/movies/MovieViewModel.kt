package com.teguh.moviejetpack.ui.movies

import androidx.lifecycle.ViewModel
import com.teguh.moviejetpack.data.repo.AppRepository

class MovieViewModel(private val appRepository: AppRepository): ViewModel() {

    fun getAllMovies() = appRepository.getNowPlayingMovies()

}
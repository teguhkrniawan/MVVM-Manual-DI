package com.teguh.moviejetpack.ui.movies

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.teguh.moviejetpack.R
import com.teguh.moviejetpack.databinding.FragmentMoviesBinding
import com.teguh.moviejetpack.factory.ViewModelFactory

class MoviesFragment : Fragment() {

    private lateinit var binding: FragmentMoviesBinding

    companion object {
        var TAG: String = MoviesFragment::class.java.simpleName
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentMoviesBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (activity != null) {

            showProgress(true)

            val factory = ViewModelFactory.getInstance()
            val viewModel = ViewModelProvider(requireActivity(), factory)[MovieViewModel::class.java]
            val movieAdapter = MovieAdapter()

            viewModel.getAllMovies().observe(viewLifecycleOwner, Observer { listMovies ->
               if (listMovies.isNotEmpty()) {
                   showProgress(false)
                   movieAdapter.setListMovies(listMovies)
                   with(binding.movieRecyclerview) {
                       layoutManager = LinearLayoutManager(context)
                       setHasFixedSize(true)
                       adapter = movieAdapter
                   }
               }
            })

        }
    }

    private fun showProgress(state: Boolean) {
        if (state) {
            binding.progressMovies.visibility = View.VISIBLE
        } else {
            binding.progressMovies.visibility = View.GONE
        }
    }

}
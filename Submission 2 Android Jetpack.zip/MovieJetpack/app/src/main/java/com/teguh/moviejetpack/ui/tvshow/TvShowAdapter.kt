package com.teguh.moviejetpack.ui.tvshow

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.teguh.moviejetpack.R
import com.teguh.moviejetpack.data.TvShow
import com.teguh.moviejetpack.databinding.ListItemsMoviesBinding
import com.teguh.moviejetpack.network.ApiClient
import com.teguh.moviejetpack.ui.detail.DetailActivity

class TvShowAdapter : RecyclerView.Adapter<TvShowAdapter.MyViewHolder>(){

    private val listTvShow = ArrayList<TvShow>()

    inner class MyViewHolder(private val binding: ListItemsMoviesBinding): RecyclerView.ViewHolder(binding.root) {
        fun bind(tvshow: TvShow) {
            with(binding) {
                binding.itemsMovieTitle.text = tvshow.originalName
                binding.itemsMovieVote.text = itemView.resources.getString(R.string.rate, tvshow.averageVote)
                Glide.with(itemView.context)
                    .load(ApiClient.IMG_PATH_URL + tvshow.posterPath)
                    .apply(RequestOptions.placeholderOf(R.drawable.ic_loading))
                    .error(R.drawable.ic_error)
                    .into(this.itemsMoviePoster)
                itemView.setOnClickListener {
                    val intent = Intent(itemView.context, DetailActivity::class.java)
                    intent.putExtra(DetailActivity.EXTRA_CATEGORIES, "tvshow")
                    intent.putExtra(DetailActivity.EXTRA_ID, tvshow.idTvshow)
                    itemView.context.startActivity(intent)
                }
            }
        }
    }

    fun setlistTvShow(list: List<TvShow>?) {
        if (list == null)
            return
        listTvShow.clear()
        listTvShow.addAll(list)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TvShowAdapter.MyViewHolder {
        val binding = ListItemsMoviesBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return listTvShow.size
    }

    override fun onBindViewHolder(holder: TvShowAdapter.MyViewHolder, position: Int) {
       val tvshow = listTvShow[position]
       holder.bind(tvshow)
    }

}
package com.teguh.moviejetpack.ui.tvshow

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.teguh.moviejetpack.R
import com.teguh.moviejetpack.databinding.FragmentTvShowBinding
import com.teguh.moviejetpack.di.Injection
import com.teguh.moviejetpack.factory.ViewModelFactory

class TvShowFragment : Fragment() {

    private lateinit var binding: FragmentTvShowBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentTvShowBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        showProgress(true)

        val factory = ViewModelFactory.getInstance()
        val viewmodel = ViewModelProvider(requireActivity(), factory)[TvShowViewModel::class.java]
        val tvshowAdapter = TvShowAdapter()

        viewmodel.getTvShow().observe(viewLifecycleOwner, Observer {list ->
            if (list.isNotEmpty()) {
                showProgress(false)
                tvshowAdapter.setlistTvShow(list)
                with(binding.tvshowRecyclerview) {
                    layoutManager = LinearLayoutManager(context)
                    setHasFixedSize(true)
                    this.adapter = tvshowAdapter
                }
            }
        })

    }

    private fun showProgress(state: Boolean) {
        if (state) {
            binding.progressTvShow.visibility = View.VISIBLE
        } else {
            binding.progressTvShow.visibility = View.GONE
        }
    }

}
package com.teguh.moviejetpack.ui.tvshow

import androidx.lifecycle.ViewModel
import com.teguh.moviejetpack.data.repo.AppRepository

class TvShowViewModel (private val appRepository: AppRepository): ViewModel() {

    fun getTvShow() = appRepository.getPopularTvShow()

}
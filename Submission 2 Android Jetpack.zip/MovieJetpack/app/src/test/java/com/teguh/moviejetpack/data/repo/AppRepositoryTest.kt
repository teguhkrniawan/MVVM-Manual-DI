package com.teguh.moviejetpack.data.repo

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.nhaarman.mockitokotlin2.any
import com.nhaarman.mockitokotlin2.doAnswer
import com.nhaarman.mockitokotlin2.eq
import com.nhaarman.mockitokotlin2.verify
import com.teguh.moviejetpack.data.source.remote.RemoteDataCallback
import com.teguh.moviejetpack.data.source.remote.RemoteDataSource
import com.teguh.moviejetpack.utils.LiveDataTestUtil
import com.teguh.moviejetpack.utils.MyDummyData
import kotlinx.coroutines.runBlocking
import org.junit.Test

import org.junit.Assert.*
import org.junit.Rule
import org.mockito.Mockito

class AppRepositoryTest {

    @get:Rule
    var instantTaskExecutor = InstantTaskExecutorRule()

    private val remote = Mockito.mock(RemoteDataSource::class.java)
    private val appRepository = FakeAppRepositoryTest(remote)

    private val listMoviesResponse = MyDummyData.generateMoviesResponse()
    private val listTvShowResponse = MyDummyData.generteTvShowResponse()
    private val movieResponse = MyDummyData.generateMoviesResponse()[0]
    private val tvShowResponse = MyDummyData.generteTvShowResponse()[0]
    private val movieID = listMoviesResponse[0].id
    private val tvShowID = listTvShowResponse[0].id


    @Test
    fun getNowPlayingMovies() {
        runBlocking {
            /** invocation.argument[index] tergantung brp params dari function callback kamu dapatkan
             *  misal ni kan  callback dari onMoviewReceived kan dia ngelempar 1 argumen berarti sef aja sesuai index nya yaitu 0
             */
            doAnswer { invocation ->
                (invocation.arguments[0] as RemoteDataCallback).onMovieReceived(listMoviesResponse)
                null
            }.`when`(remote).loadNowPlayingMovies(any())
        }

        val data = LiveDataTestUtil.getValue(appRepository.getNowPlayingMovies())

        runBlocking {
            verify(remote).loadNowPlayingMovies(any())
        }

        assertNotNull(data)
        assertEquals(listMoviesResponse.size, data.size)
    }

    @Test
    fun getPopularTvShow() {
        runBlocking {
            doAnswer { invocation ->
                (invocation.arguments[0] as RemoteDataCallback).onTvShowReceived(listTvShowResponse)
                null
            }.`when`(remote).loadPopularTvShow(any())
        }

        val data = LiveDataTestUtil.getValue(appRepository.getPopularTvShow())

        runBlocking {
            verify(remote).loadPopularTvShow(any())
        }

        assertNotNull(data)
        assertEquals(listMoviesResponse.size, data.size)
    }

    @Test
    fun getDetailMovie() {
        runBlocking {
            doAnswer { invocation ->
                (invocation.arguments[1] as RemoteDataCallback).onDetailMovieReceiverd(movieResponse)
                null
            }.`when`(remote).loadDetailMovies(eq(movieID!!), any())
        }

        val data = LiveDataTestUtil.getValue(appRepository.getDetailMovie(movieID!!))

        runBlocking {
            verify(remote).loadDetailMovies(eq(movieID), any())
        }

        assertNotNull(data)
        assertEquals(movieResponse.id, data.idMovie?.toInt())
    }

    @Test
    fun getDetailTvShow() {
        runBlocking {
            doAnswer { invocation ->
                (invocation.arguments[1] as RemoteDataCallback).onDetailTvShowReceived(tvShowResponse)
                null
            }.`when`(remote).loadDetailTvShow(eq(tvShowID!!), any())
        }

        val data = LiveDataTestUtil.getValue(appRepository.getDetailTvShow(tvShowID!!))

        runBlocking {
            verify(remote).loadDetailTvShow(eq(tvShowID), any())
        }

        assertNotNull(data)
        assertEquals(tvShowResponse.id, data.idTvshow?.toInt())
    }
}
package com.teguh.moviejetpack.data.repo

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.teguh.moviejetpack.data.Movies
import com.teguh.moviejetpack.data.TvShow
import com.teguh.moviejetpack.data.source.remote.RemoteDataCallback
import com.teguh.moviejetpack.data.source.remote.RemoteDataSource
import com.teguh.moviejetpack.data.source.remote.response.MovieResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.launch

class FakeAppRepositoryTest (private val remoteDataSource: RemoteDataSource): AppRepoCallback{

    companion object {
        var TAG: String = FakeAppRepositoryTest::class.java.simpleName
    }

    override fun getNowPlayingMovies(): LiveData<List<Movies>> {

        val listMoviesLiveData = MutableLiveData<List<Movies>>()

        CoroutineScope(IO).launch {
            remoteDataSource.loadNowPlayingMovies(object : RemoteDataCallback {
                override fun onMovieReceived(movieResponse: List<MovieResponse>) {

                    val listMovies = ArrayList<Movies>()

                    for (item in movieResponse) {
                        val id = item.id
                        val title = item.title
                        val poster = item.posterPath
                        val overview = item.overview
                        val vote = item.voteAverage

                        val movies = Movies(id.toString(), title, overview, vote.toString(), poster)
                        listMovies.add(movies)
                    }
                    listMoviesLiveData.postValue(listMovies)
                }

                override fun onFailedResponse(message: String) {
                    Log.d(TAG, "failed from retrofit: $message")
                }
            })
        }

        return listMoviesLiveData
    }

    override fun getPopularTvShow(): LiveData<List<TvShow>> {

        val listTvShowLiveData = MutableLiveData<List<TvShow>>()

        CoroutineScope(IO).launch {
            remoteDataSource.loadPopularTvShow(object : RemoteDataCallback {
                override fun onTvShowReceived(tvShowResponse: List<MovieResponse>) {
                    val list = ArrayList<TvShow>()
                    for (item in tvShowResponse) {

                        val idTvShow = item.id
                        val originalname = item.originalName
                        val overview = item.overview
                        val averageVote = item.voteAverage
                        val posterPath = item.posterPath

                        val tvShow = TvShow(
                            idTvShow.toString(), originalname, overview, averageVote.toString(), posterPath
                        )
                        list.add(tvShow)
                    }
                    listTvShowLiveData.postValue(list)
                }

                override fun onFailedResponse(message: String) {
                    Log.d(TAG, "Tv show failed to get because $message")
                }
            })
        }
        return listTvShowLiveData
    }

    override fun getDetailMovie(idMovies: Int): LiveData<Movies> {

        val moviesLiveData = MutableLiveData<Movies>()

        CoroutineScope(IO).launch {
            remoteDataSource.loadDetailMovies(idMovies, object : RemoteDataCallback {
                override fun onFailedResponse(message: String) {
                    Log.d(TAG, "Detail movies failed to get because $message")
                }

                override fun onDetailMovieReceiverd(movies: MovieResponse) {
                    val myMovieModel = Movies(
                        movies.id.toString(),
                        movies.title.toString(),
                        movies.overview.toString(),
                        movies.voteAverage.toString(),
                        movies.posterPath.toString()
                    )
                    moviesLiveData.postValue(myMovieModel)
                }
            })
        }
        return moviesLiveData
    }

    override fun getDetailTvShow(idTvShow: Int): LiveData<TvShow> {

        val tvShowLiveData = MutableLiveData<TvShow>()

        CoroutineScope(IO).launch {
            remoteDataSource.loadDetailTvShow(idTvShow, object : RemoteDataCallback {
                override fun onFailedResponse(message: String) {
                    Log.d(TAG, "Detail movies failed to get because $message")
                }

                override fun onDetailTvShowReceived(tvshow: MovieResponse) {
                    super.onDetailTvShowReceived(tvshow)
                    val myTvShow = TvShow(
                        tvshow.id.toString(),
                        tvshow.originalName,
                        tvshow.overview,
                        tvshow.voteAverage.toString(),
                        tvshow.posterPath
                    )
                    tvShowLiveData.postValue(myTvShow)
                }
            })
        }
        return tvShowLiveData
    }

}
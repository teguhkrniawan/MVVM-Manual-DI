package com.teguh.moviejetpack.ui.detail

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.nhaarman.mockitokotlin2.verify
import com.teguh.moviejetpack.data.Movies
import com.teguh.moviejetpack.data.TvShow
import com.teguh.moviejetpack.data.repo.AppRepository
import com.teguh.moviejetpack.utils.MyDummyData
import org.junit.Test

import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito.`when`
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class DetailViewModelTest {

    private val dummyMovie = MyDummyData.generateMovies()[0]
    private val idMovie = dummyMovie.idMovie?.toInt()

    private val dummyTvShow = MyDummyData.generateTvShow()[0]
    private val idTvShow = dummyTvShow.idTvshow

    private lateinit var viewModel: DetailViewModel

    @get:Rule
    var intantTaskExecutor = InstantTaskExecutorRule()

    @Mock
    private lateinit var appRepository: AppRepository

    @Mock
    private lateinit var observerMovie: Observer<Movies>

    @Mock
    private lateinit var observerTvShow: Observer<TvShow>

    @Before
    fun setup() {
        viewModel = DetailViewModel(appRepository)
    }

    @Test
    fun getDetailMovie(){
        val movieLiveData = MutableLiveData<Movies>()
        movieLiveData.value = dummyMovie

        assertNotNull(idMovie)
        `when`(appRepository.getDetailMovie(idMovie!!)).thenReturn(movieLiveData)

        viewModel.setIdMovie(idMovie.toString())
        val movieData = viewModel.getmovieDetail().value as Movies

        assertNotNull(movieData)
        assertEquals(dummyMovie.idMovie, movieData.idMovie)
        assertEquals(dummyMovie.originalTitle, movieData.originalTitle)
        assertEquals(dummyMovie.overview, movieData.overview)
        assertEquals(dummyMovie.voteAverage, movieData.voteAverage)
        assertEquals(dummyMovie.posterPath, movieData.posterPath)

        viewModel.getmovieDetail().observeForever(observerMovie)
        verify(observerMovie).onChanged(dummyMovie)
    }

    @Test
    fun getDetailTvShow() {
        val tvShowLiveData = MutableLiveData<TvShow>()
        tvShowLiveData.value = dummyTvShow

        assertNotNull(idTvShow)
        `when`(appRepository.getDetailTvShow(idTvShow!!.toInt())).thenReturn(tvShowLiveData)

        viewModel.setIdTvShow(idTvShow)
        val tvShow = viewModel.getTvShowDetail().value as TvShow

        assertNotNull(tvShow)
        assertEquals(dummyTvShow.idTvshow, tvShow.idTvshow)
        assertEquals(dummyTvShow.originalName, tvShow.originalName)
        assertEquals(dummyTvShow.overview, tvShow.overview)
        assertEquals(dummyTvShow.averageVote, tvShow.averageVote)
        assertEquals(dummyTvShow.posterPath, tvShow.posterPath)

        viewModel.getTvShowDetail().observeForever(observerTvShow)
        verify(observerTvShow).onChanged(dummyTvShow)
    }
}
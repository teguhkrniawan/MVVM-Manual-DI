package com.teguh.moviejetpack.ui.movies

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.teguh.moviejetpack.data.Movies
import com.teguh.moviejetpack.data.repo.AppRepository
import com.teguh.moviejetpack.utils.MyDummyData
import org.junit.Test

import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito.`when`
import org.mockito.Mockito.verify
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class MovieViewModelTest {

    private lateinit var viewModel: MovieViewModel
    private val dummmyMovies = MyDummyData.generateMovies()

    // untuk testing asyncronus
    @get:Rule
    var instantTaskExecutor = InstantTaskExecutorRule()

    @Mock
    private lateinit var appRepository: AppRepository

    @Mock
    private lateinit var observer: Observer<List<Movies>>

    @Before
    fun setup() {
        viewModel = MovieViewModel(appRepository)
    }

    @Test
    fun getAllMovies() {
        val movie = MutableLiveData<List<Movies>>()
        movie.value = dummmyMovies

        `when`(appRepository.getNowPlayingMovies()).thenReturn(movie)

        // tanpa .value nilainya variabel ini LiveData
        val listMovies = viewModel.getAllMovies().value

        verify(appRepository).getNowPlayingMovies()
        assertNotNull(listMovies)
        assertEquals(10, listMovies?.size)

        viewModel.getAllMovies().observeForever(observer)
        verify(observer).onChanged(dummmyMovies)
    }
}
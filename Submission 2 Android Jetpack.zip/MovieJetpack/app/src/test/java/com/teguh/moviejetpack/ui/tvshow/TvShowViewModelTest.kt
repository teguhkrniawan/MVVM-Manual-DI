package com.teguh.moviejetpack.ui.tvshow

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.nhaarman.mockitokotlin2.verify
import com.teguh.moviejetpack.data.TvShow
import com.teguh.moviejetpack.data.repo.AppRepository
import com.teguh.moviejetpack.utils.MyDummyData
import org.junit.Test

import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito.`when`
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class TvShowViewModelTest {

    private lateinit var viewModel: TvShowViewModel
    private val dummyTvShow = MyDummyData.generateTvShow()

    @get:Rule
    var instantTaskExecutor = InstantTaskExecutorRule()

    @Mock
    private lateinit var appRepository: AppRepository

    @Mock
    private lateinit var observer : Observer<List<TvShow>>

    @Before
    fun setup() {
        viewModel = TvShowViewModel(appRepository)
    }

    @Test
    fun getTvShow() {
        val tvShow = MutableLiveData<List<TvShow>>()
        tvShow.value = dummyTvShow

        `when`(appRepository.getPopularTvShow()).thenReturn(tvShow)
        val listTvShow = viewModel.getTvShow().value

        verify(appRepository).getPopularTvShow()
        assertNotNull(listTvShow)
        assertEquals(10, listTvShow?.size)

        viewModel.getTvShow().observeForever(observer)
        verify(observer).onChanged(dummyTvShow)
    }
}